import os
import sqlite3
from flask import Flask, render_template, request, redirect, session, url_for, flash, send_file, jsonify
import webbrowser
import random
from algo import func
app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.route('/home')
def home():
	return render_template("home.html")

@app.route('/login')
def login():
	return render_template("login.html")

@app.route('/signup')
def signup():
	return render_template("signup.html")

@app.route('/query')
def query():
	return render_template("query.html")

@app.route('/signup',methods=['POST', 'GET'])
def signup_form():
	if request.method=='POST':
		login_id=request.form.get('login_id')
		password=request.form.get('password')
		cnfrm_password=request.form.get('cnfrm_password')
		designation=request.form.get('designation')
		conn = sqlite3.connect("data.db")
		cur = conn.cursor()
		cur.execute("INSERT INTO employee_details VALUES(?,?,?);", (login_id, password, designation))
		conn.commit()
		conn.close()
		return redirect('/query')

@app.route('/login',methods=['POST', 'GET'])
def login_form():
	if request.method=='POST':
		login_id=request.form.get('login_id')
		password=request.form.get('password')
		conn = sqlite3.connect("data.db")
		cur = conn.cursor()
		results = cur.execute("select * from employee_details where login_id == ? and password == ?;", (login_id,password,)).fetchall()
		if results:
			print("asdfghjklqwertyui")
			return render_template("query.html", status = 0)
		else:			
			return render_template("query.html", status = 1)

@app.route('/query',methods=['POST', 'GET'])
def query_form():
	if request.method=='POST':
		qry=request.form.get('q')
		conn = sqlite3.connect("data.db")
		cur = conn.cursor()
		cur.execute("INSERT INTO queries VALUES(?);", (qry,))
		conn.commit()
		conn.close()
		eq = func(qry)
		orig = qry
		print("this is sample")
		return render_template("query.html", status = 2, qry = eq, orig = orig)

@app.route('/results',methods=['POST', 'GET'])
def results():
	if request.method=='POST':
		qry=request.form.get('q')
		conn = sqlite3.connect("data.db")
		cur = conn.cursor()
		cur.execute("INSERT INTO queries VALUES(?);", (qry,))
		qry_str = str(qry)
		print(qry)
		res = cur.execute(qry_str).fetchall()
		print(len(res[0]))
		conn.commit()
		conn.close()
		return render_template("results.html", status = 2,res = res)

if __name__ == '__main__':
	app.run(debug=True)
