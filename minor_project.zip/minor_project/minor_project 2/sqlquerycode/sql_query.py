from nltk import load_parser

cp = load_parser('/home/chaitanya/Work/minor_project/sqlquerycode/sql0.fcfg')
query = 'What states are located in India'

trees = list(cp.parse(query.split()))

answer = trees[0].label()['SEM']
answer = [s for s in answer if s]

q = ' '.join(answer)
print(q)
